<?php
// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'enrollment_db');
if ($conn->connect_error) {
    die(json_encode([
        "status"  => "error",
        "message" => "Database connection failed: " . $conn->connect_error
    ]));
}

// Helper function to safely get POST data
function getPost($key) {
    return isset($_POST[$key]) && trim($_POST[$key]) !== '' ? trim($_POST[$key]) : null;
}

// Ensure the form is submitted via POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode([
        "status"  => "error",
        "message" => "Error: Form not submitted properly."
    ]));
}

// Validate required fields
$requiredFields = [
    'email', 'lastName', 'firstName', 'yrlvl',
    'birthday', 'contact', 'address', 'street', 'city', 'province'
];
foreach ($requiredFields as $field) {
    if (empty(getPost($field))) {
        die(json_encode([
            "status"  => "error",
            "message" => "Error: Missing required field '$field'."
        ]));
    }
}

// Map year level (e.g., "1st year" to 1)
$yearMap = ['1st year' => 1, '2nd year' => 2, '3rd year' => 3, '4th year' => 4];
$numericYear = $yearMap[getPost('yrlvl')] ?? null;
if (!$numericYear) {
    die(json_encode([
        "status"  => "error",
        "message" => "Error: Invalid Year Level Selection."
    ]));
}

// Retrieve basic form data
$admissionType   = getPost('admissionType') ?: '';
$lastName        = getPost('lastName');
$firstName       = getPost('firstName');
$middleName      = getPost('middleName') ?: '';
$workingStudent  = getPost('workingStudent') ?: 'no';
$gender          = getPost('gender') ?: '';
$civilStatus     = getPost('civilStatus') ?: '';
$religion        = getPost('religion') ?: '';
$birthday        = getPost('birthday');
$address         = getPost('address');
$street          = getPost('street');
$city            = getPost('city');
$province        = getPost('province');
$postal          = getPost('postal') ?: '';
$contact         = getPost('contact'); // Assume this is the student's phone number
$email           = getPost('email');

// Begin a transaction to ensure data consistency
$conn->begin_transaction();

try {
    // ---------------------------
    // Enrollment Insertion
    // ---------------------------
    // We are using the column name "phone" for the contact number.
    $stmt = $conn->prepare("
        INSERT INTO pending_enrollments (
            admission_type, last_name, first_name, middle_name,
            working_student, gender, civil_status, religion,
            year_level, birthday, contact, email, address, street, city, province, postal, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    // Set the default status for enrollment requests
    $status = 'pending';

    /*
     * Bind parameters:
     * - 1st 8 columns: strings (s)
     * - 9th column: integer (i)
     * - Next 9 columns: strings (s)
     * Total: 18 parameters → "ssssssssisssssssss"
     */
    $stmt->bind_param("ssssssssisssssssss",
        $admissionType,   // admission_type: string
        $lastName,        // last_name: string
        $firstName,       // first_name: string
        $middleName,      // middle_name: string
        $workingStudent,  // working_student: string
        $gender,          // gender: string
        $civilStatus,     // civil_status: string
        $religion,        // religion: string
        $numericYear,     // year_level: integer
        $birthday,        // birthday: string
        $contact,         // phone: string (using "phone" as column name)
        $email,           // email: string
        $address,         // address: string
        $street,          // street: string
        $city,            // city: string
        $province,        // province: string
        $postal,          // postal: string
        $status           // status: string
    );

    if (!$stmt->execute()) {
        throw new Exception("Error: Enrollment submission failed - " . $stmt->error);
    }

    // Get the auto-generated student ID (the enrollment record ID)
    $studentID = $conn->insert_id;
    $stmt->close();

    // ---------------------------
    // Emergency Contacts Insertion
    // ---------------------------
    // Again, we use "phone" as the column name for contact information.
    $emergencyContacts = [
        ["father", getPost('fatherLastName'), getPost('fatherFirstName'), getPost('fatherMiddleName'), getPost('fatherContact')],
        ["mother", getPost('motherLastName'), getPost('motherFirstName'), getPost('motherMiddleName'), getPost('motherContact')],
        ["guardian", getPost('guardianLastName'), getPost('guardianFirstName'), getPost('guardianMiddleName'), getPost('guardianContact')]
    ];

    $stmt = $conn->prepare("
        INSERT INTO emergency_contacts (
            student_id, contact_type, last_name, first_name, middle_name, contact
        ) VALUES (?, ?, ?, ?, ?, ?)
    ");

    foreach ($emergencyContacts as $ec) {
        list($type, $ecLastName, $ecFirstName, $ecMiddleName, $ecContact) = $ec;
        // Ensure essential emergency contact fields are provided
        if (!empty($ecLastName) && !empty($ecFirstName) && !empty($ecContact)) {
            $stmt->bind_param("isssss",
                $studentID,    // student_id: integer
                $type,         // contact_type: string
                $ecLastName,   // last_name: string
                $ecFirstName,  // first_name: string
                $ecMiddleName, // middle_name: string
                $ecContact     // phone: string (using "phone" as column name)
            );
            if (!$stmt->execute()) {
                throw new Exception("Error: Emergency contact submission failed - " . $stmt->error);
            }
        }
    }
    $stmt->close();

    // Commit the transaction after all insertions have succeeded
    $conn->commit();

    echo json_encode([
        "status"  => "success",
        "message" => "Enrollment request submitted successfully!"
    ]);
} catch (Exception $e) {
    // Roll back the transaction if an error occurs
    $conn->rollback();
    die(json_encode([
        "status"  => "error",
        "message" => $e->getMessage()
    ]));
}

$conn->close();
?>
