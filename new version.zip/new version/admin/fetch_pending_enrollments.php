<?php
$conn = new mysqli('localhost', 'root', '', 'enrollment_db');

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}

// Secure Query Preparation with aliasing student_id as id
$query = "SELECT student_id AS id, first_name, last_name, year_level FROM pending_enrollments WHERE status = ?";
$stmt = $conn->prepare($query);
$status = 'pending';
$stmt->bind_param("s", $status);
$stmt->execute();
$result = $stmt->get_result();

// Handle Empty Results
if ($result->num_rows === 0) {
    echo "<tr><td colspan='3'>No pending enrollments found.</td></tr>";
    exit();
}

// Using Output Buffering to Handle HTML Output Safely
ob_start();

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['first_name']} {$row['last_name']}</td>
        <td>Year {$row['year_level']}</td>
        <td>
            <form action='approve_enrollment.php' method='POST'>
                <input type='hidden' name='request_id' value='{$row['id']}'>
                <button type='submit' name='action' value='approved'>Approve</button>
                <button type='submit' name='action' value='rejected'>Reject</button>
            </form>
        </td>
    </tr>";
}

$stmt->close();
$conn->close();

echo ob_get_clean();
?>
