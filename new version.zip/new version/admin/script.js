// Initialize Chart.js chart on page load if canvas exists
let ctx = document.getElementById('studentChart')?.getContext('2d');
let studentChart = ctx ? new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Year 1', 'Year 2', 'Year 3', 'Year 4'],
    datasets: [{
      label: 'Overview',
      backgroundColor: 'blue',
      data: [40, 35, 50, 45]
    }]
  },
  options: {
    responsive: true
  }
}) : null;

// Example fetch for student count (ensure your HTML has an element for this if needed)
fetch('login_data.php')
  .then(response => response.json())
  .then(data => {
    // For example, if you add an element with id "studentCount"
    const studentCountElem = document.getElementById('studentCount');
    if (studentCountElem) studentCountElem.textContent = data.total_students;
  })
  .catch(error => console.error("Error fetching student count:", error));

// Function to update the chart based on selected statistic
function updateChart(statType) {
  if (!studentChart) return;
  let newData = [];
  let newTitle = '';

  switch(statType) {
    case 'students': 
      newData = [40, 35, 50, 45]; 
      newTitle = 'Total Students Overview'; 
      break;
    case 'faculty': 
      newData = [10, 15, 20, 12]; 
      newTitle = 'Faculty Members Overview'; 
      break;
    case 'attendance': 
      newData = [75, 80, 85, 78]; 
      newTitle = 'Attendance Rates Overview'; 
      break;
    case 'classes': 
      newData = [8, 10, 12, 14]; 
      newTitle = 'Active Classes Overview'; 
      break;
  }

  document.getElementById('chartTitle').textContent = newTitle;
  studentChart.data.datasets[0].data = newData;
  studentChart.data.datasets[0].label = newTitle;
  studentChart.update();
}

// Change content based on sidebar selection
function changeContent(section) {
  const dynamicContent = document.getElementById('dynamicContent');
  if (!dynamicContent) return;
  
  if (section === 'students') {
    // Fetch pending enrollment data (or approved students depending on your implementation)
    fetch('fetch_pending_enrollments.php')
      .then(response => response.text())
      .then(data => {
        dynamicContent.innerHTML = `
          <header class="header">
            <h2>Student Management</h2>
            <input type="text" id="searchBar" placeholder="Search students..." class="search-bar" oninput="filterStudents()">
          </header>
          <section class="student-data">
            <h3>Pending Enrollment Requests</h3>
            <table class="data-table" id="studentTable">
              <thead>
                <tr>
                  <th>Student Name</th>
                  <th>Year Level</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                ${data}
              </tbody>
            </table>
          </section>
        `;
      })
      .catch(error => {
        console.error("Error fetching enrollments:", error);
        dynamicContent.innerHTML = "<p>Error loading student data.</p>";
      });
  } else {
    let newContent = '';

    switch (section) {
      case 'dashboard':
        newContent = `
          <header class="header">
            <h2 id="contentHeader">Dashboard</h2>
            <input type="text" id="searchBar" placeholder="Search for it..." class="search-bar">
          </header>
          <section class="stats">
            <a href="#" class="stat-box" onclick="updateChart('students')">Total Students</a>
            <a href="#" class="stat-box" onclick="updateChart('faculty')">Faculty Members</a>
            <a href="#" class="stat-box" onclick="updateChart('attendance')">Attendance Rates</a>
            <a href="#" class="stat-box" onclick="updateChart('classes')">Active Classes</a>
          </section>
          <section class="chart">
            <h2 id="chartTitle">Overview</h2>
            <canvas id="studentChart"></canvas>
          </section>
        `;
        break;
      case 'teachers':
        newContent = `
          <header class="header">
            <h2>Teachers Attendance</h2>
            <input type="text" placeholder="Search teachers..." class="search-bar">
          </header>
          <section class="attendance-data">
            <p>Track attendance and schedule reports for teachers.</p>
          </section>
        `;
        break;
    }

    dynamicContent.innerHTML = newContent;

    // Reinitialize the Chart if dashboard is loaded
    if (section === 'dashboard') {
      let ctx = document.getElementById('studentChart')?.getContext('2d');
      if (ctx) {
        studentChart = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: ['Year 1', 'Year 2', 'Year 3', 'Year 4'],
            datasets: [{
              label: 'Overview',
              backgroundColor: 'blue',
              data: [40, 35, 50, 45]
            }]
          },
          options: { responsive: true }
        });
      }
    }
  }
}

// Function for filtering students. (Use the searchBar and studentTable IDs)
function filterStudents() {
  let input = document.getElementById("searchBar").value.toLowerCase();
  let table = document.getElementById("studentTable");
  if (!table) return;
  let rows = table.getElementsByTagName("tr");

  for (let i = 1; i < rows.length; i++) {
      let nameText = rows[i].getElementsByTagName("td")[0].textContent.toLowerCase();
      rows[i].style.display = nameText.includes(input) ? "" : "none";
  }
}

// Functions to view, edit, and delete students (these use fetch to communicate with backend PHP scripts)
function viewStudent(studentId) {
  fetch(`view_student.php?id=${studentId}`)
    .then(response => response.text())
    .then(data => {
      const detailsElem = document.getElementById("studentDetails");
      if (detailsElem) {
        detailsElem.innerHTML = data;
        detailsElem.style.display = "block";
      }
    })
    .catch(error => console.error("Error fetching student details:", error));
}

function editStudent(studentId) {
  fetch(`edit_student.php?student_id=${studentId}`)
    .then(response => response.text())
    .then(data => {
      const formElem = document.getElementById("studentForm");
      if (formElem) {
        formElem.innerHTML = data;
        formElem.style.display = "block";
      }
    })
    .catch(error => console.error("Error fetching edit form:", error));
}

function deleteStudent(studentId) {
  if (confirm("Are you sure you want to delete this student?")) {
    fetch(`delete_student.php?id=${studentId}`, { method: "POST" })
      .then(response => response.text())
      .then(data => {
        alert(data);
        location.reload();
      })
      .catch(error => console.error("Error deleting student:", error));
  }
}
