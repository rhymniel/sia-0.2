<?php
$conn = new mysqli('localhost', 'root', '', 'enrollment_db');

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}

$request_id = $_POST['request_id'] ?? null;
$action = $_POST['action'] ?? null;

// Validate request ID and action
if (!$request_id || !in_array($action, ['approved', 'rejected'])) {
    die(json_encode(["status" => "error", "message" => "Invalid request."]));
}

// Fetch Student Details from pending_enrollments using student_id
$stmt = $conn->prepare("SELECT * FROM pending_enrollments WHERE student_id = ?");
$stmt->bind_param("i", $request_id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
$stmt->close();

if (!$student) {
    die(json_encode(["status" => "error", "message" => "Enrollment request not found."]));
}

// Handle rejection: update pending_enrollments record using student_id
if ($action === 'rejected') {
    $stmt = $conn->prepare("UPDATE pending_enrollments SET status = 'rejected' WHERE student_id = ?");
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $stmt->close();
    die(json_encode(["status" => "success", "message" => "Enrollment rejected."]));
}

// BEGIN TRANSACTION to prevent partial inserts
$conn->begin_transaction();

try {
    // Generate a new Student ID based on the year
    function generateStudentID($conn, $year) {
        $prefix = $year * 10000;
        $query = $conn->query("SELECT MAX(student_id) AS last_id FROM students WHERE year_level = $year");
        $lastID = ($query && $row = $query->fetch_assoc()) ? ($row['last_id'] % 10000 + 1) : 1;
        return $prefix + $lastID;
    }

    $student_id = generateStudentID($conn, $student['year_level']);

    // Generate Username & Password
    $username = (string)$student_id;
    $password = "#" . substr($student['last_name'], 0, 2) . "8080";

    // Move from pending_enrollments to students
    $stmt = $conn->prepare("
        INSERT INTO students (student_id, admission_type, last_name, first_name, middle_name, 
            working_student, gender, civil_status, religion, year_level, birthday)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("issssssssis",
        $student_id, 
        $student['admission_type'], 
        $student['last_name'], 
        $student['first_name'],
        $student['middle_name'], 
        $student['working_student'], 
        $student['gender'],
        $student['civil_status'], 
        $student['religion'], 
        $student['year_level'], 
        $student['birthday']
    );
    if (!$stmt->execute()) {
        throw new Exception("Error inserting student record.");
    }
    $stmt->close();

    // Create Login Account
    $stmt = $conn->prepare("INSERT INTO logins (student_id, username, password) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $student_id, $username, password_hash($password, PASSWORD_BCRYPT));
    if (!$stmt->execute()) {
        throw new Exception("Error inserting login record.");
    }
    $stmt->close();

    // Update Enrollment Status to 'approved' using student_id
    $stmt = $conn->prepare("UPDATE pending_enrollments SET status = 'approved' WHERE student_id = ?");
    $stmt->bind_param("i", $request_id);
    if (!$stmt->execute()) {
        throw new Exception("Error updating enrollment status.");
    }
    $stmt->close();

    // COMMIT TRANSACTION if everything succeeds
    $conn->commit();

    echo json_encode([
        "status"   => "success",
        "message"  => "Enrollment approved!",
        "student_id" => $student_id,
        "username" => $username
    ]);
} catch (Exception $e) {
    // ROLLBACK TRANSACTION if something fails
    $conn->rollback();
    die(json_encode(["status" => "error", "message" => $e->getMessage()]));
}

$conn->close();
?>
