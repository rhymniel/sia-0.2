<script>
  // Function to show login credentials after enrollment
  function showLoginCredentials() {
      // Retrieve data from session storage (sent after form submission)
      let studentID = sessionStorage.getItem("studentID");
      let lastName = sessionStorage.getItem("lastName");

      // Generate password based on last name
      let password = lastName ? `#${lastName.substring(0,2).toUpperCase()}8080` : "#XX8080"; // Default if last name missing

      // Show popup alert with credentials
      alert(`Enrollment Successful! \n\nUsername: ${studentID} \nPassword: ${password}`);
  }

  // Run function when page loads
  window.onload = function() {
      showLoginCredentials();
  };
</script>
