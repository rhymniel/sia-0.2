<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'enrollment_db');

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Ensure admin table exists (If missing, create it)
$adminTableCheck = "SHOW TABLES LIKE 'admin'";
$adminResult = mysqli_query($conn, $adminTableCheck);
if (mysqli_num_rows($adminResult) == 0) {
    $createAdminTable = "CREATE TABLE admin (
        admin_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL
    )";
    mysqli_query($conn, $createAdminTable);
}

// Retrieve and sanitize inputs
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if (empty($username) || empty($password)) {
    echo "<script>alert('Username and Password are required.'); window.location.href='/login.html';</script>";
    exit();
}

// Initialize login attempts tracking
if (!isset($_SESSION['attempts'][$username])) {
    $_SESSION['attempts'][$username] = 0;
}

// Lockout mechanism (5 attempts = 1-minute cooldown)
if ($_SESSION['attempts'][$username] >= 5) {
    $lockout_time = $_SESSION['lockout'][$username] ?? 0;
    if (time() - $lockout_time < 60) {
        echo "<script>alert('Too many failed attempts. Try again after 1 minute.'); window.location.href='/login.html';</script>";
        exit();
    } else {
        $_SESSION['attempts'][$username] = 0;
        unset($_SESSION['lockout'][$username]);
    }
}

// Determine login type
if (str_starts_with($username, 's')) {
    $query = "SELECT student_id, password FROM logins WHERE username = ?";
    $redirect = "/stu/stud.html";
} elseif (str_starts_with($username, 't')) {
    $query = "SELECT teacher_id, password FROM teachers WHERE username = ?";
    $redirect = "/teach/teach.html";
} elseif (str_starts_with($username, 'admin')) {
    // **Admin Login Query (Uses Hashed Password)**
    $query = "SELECT admin_id, password FROM admin WHERE username = ?";
    $redirect = "/admin/admin.html";
} else {
    echo "<script>alert('Unknown user type. Contact support.'); window.location.href='/login.html';</script>";
    exit();
}

// Execute login query
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $storedPasswordHash = $row['password'];

    // ✅ Verify password correctly
    if (password_verify($password, $storedPasswordHash) || $password === $storedPasswordHash) {
        $_SESSION['user_id'] = $row[array_key_first($row)];
        echo "<script>window.location.href='$redirect';</script>";
        exit();
    }
}

// Failed login attempt handling
$_SESSION['attempts'][$username]++;
if ($_SESSION['attempts'][$username] >= 5) {
    $_SESSION['lockout'][$username] = time();
    echo "<script>alert('Too many failed attempts. Try again in 1 minute.'); window.location.href='/login.html';</script>";
} else {
    echo "<script>alert('Incorrect credentials. Attempt ".$_SESSION['attempts'][$username]."/5'); window.location.href='/login.html';</script>";
}

$stmt->close();
$conn->close();
?>
