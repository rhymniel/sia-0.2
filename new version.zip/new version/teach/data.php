<?php
$conn = mysqli_connect('localhost', 'root', '', 'enrollment_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to count male and female students per year level
$query = "
    SELECT year_level,
           SUM(CASE WHEN gender = 'Male' THEN 1 ELSE 0 END) AS male_count,
           SUM(CASE WHEN gender = 'Female' THEN 1 ELSE 0 END) AS female_count
    FROM students
    GROUP BY year_level
    ORDER BY year_level ASC;
";

$result = $conn->query($query);
$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Embed PHP data directly into JavaScript
echo "<script>let studentData = " . json_encode($data) . ";</script>";
$conn->close();
?>
