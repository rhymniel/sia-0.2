// Initialize Chart.js
let ctx = document.getElementById('studentChart').getContext('2d');
let studentChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Year 1', 'Year 2', 'Year 3', 'Year 4'],
        datasets: [{
            label: 'Students',
            backgroundColor: 'blue',
            data: [40, 35, 50, 45]
        }]
    },
    options: {
        responsive: true
    }
});

// Function to update chart based on clicked stat box
function updateChart(statType) {
    let newData = [];
    let newTitle = '';

    switch(statType) {
        case 'students':
            newData = [40, 35, 50, 45];
            newTitle = 'Total Students Overview';
            break;
        case 'faculty':
            newData = [10, 15, 20, 12];
            newTitle = 'Faculty Members Overview';
            break;
        case 'attendance':
            newData = [75, 80, 85, 78];
            newTitle = 'Attendance Rates Overview';
            break;
        case 'classes':
            newData = [8, 10, 12, 14];
            newTitle = 'Active Classes Overview';
            break;
    }

    // Update chart title
    document.getElementById('chartTitle').textContent = newTitle;

    // Update chart data
    studentChart.data.datasets[0].data = newData;
    studentChart.data.datasets[0].label = newTitle;
    
    // Re-render the chart
    studentChart.update();
}
function changeContent(section) {
    const mainContent = document.querySelector('.main-content');
    
    let newContent = '';

    switch (section) {
        case 'dashboard':
            newContent = `
                <header class="header">
                    <h2>Dashboard</h2>
                    <input type="text" placeholder="Search for it..." class="search-bar">
                </header>
                <section class="stats">
                    <a href="#" class="stat-box" onclick="updateChart('students')">Total Students</a>
                    <a href="#" class="stat-box" onclick="updateChart('faculty')">Faculty Members</a>
                    <a href="#" class="stat-box" onclick="updateChart('attendance')">Attendance Rates</a>
                    <a href="#" class="stat-box" onclick="updateChart('classes')">Active Classes</a>
                </section>
                <section class="chart">
                    <h2 id="chartTitle">Overview</h2>
                    <canvas id="studentChart"></canvas>
                </section>
            `;
            break;

        case 'students':
            newContent = `
                <header class="header">
                    <h2>Student Management</h2>
                    <input type="text" placeholder="Search students..." class="search-bar">
                </header>
                <section class="student-data">
                    <p>Manage student records, enrollments, and reports.</p>
                </section>
            `;
            break;

        case 'teachers':
            newContent = `
                <header class="header">
                    <h2>Teachers Attendance</h2>
                    <input type="text" placeholder="Search teachers..." class="search-bar">
                </header>
                <section class="attendance-data">
                    <p>Track attendance and schedule reports for teachers.</p>
                </section>
            `;
            break;
    }

    mainContent.innerHTML = newContent;
}
